﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Умножить_без_оператора_задние_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите целое первое число");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите целое второе число");
            int n = Convert.ToInt32(Console.ReadLine());
            int o = 0;
            for (int i = 0; i < n; i++)
            {
                o += m;
            }
            Console.WriteLine(o);
            Console.ReadKey();

        }
    }
}
