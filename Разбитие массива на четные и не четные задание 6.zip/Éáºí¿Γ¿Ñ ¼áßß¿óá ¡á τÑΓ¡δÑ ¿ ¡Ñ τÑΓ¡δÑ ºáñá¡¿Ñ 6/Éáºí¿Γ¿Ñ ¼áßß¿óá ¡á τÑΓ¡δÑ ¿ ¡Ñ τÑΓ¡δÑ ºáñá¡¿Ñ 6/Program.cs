﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Разбитие_массива_на_четные_и_не_четные_задание_6
{
    class Program
    {
        static void Main(string[] args)
        {
            {
                Random rnd = new Random();
                int[] a = new int[rnd.Next(1, 100 + 1)];
                for (int i = 0; i < a.Length; i++)
                {
                    a[i] = rnd.Next(1, 100 + 1);
                }
                int[] b = new int[a.Length];
                int[] c = new int[a.Length];
                for (int i = 0; i < a.Length; i++)
                {
                    double an = a[i] % 2;
                    if (an != 0)
                    {
                        b[i] = a[i];
                    }
                    else
                    {
                        c[i] = a[i];
                    }
                }
                Console.WriteLine("Не чётные ==");
                foreach (int i in b)
                {
                    if (i != 0)
                    {
                        Console.Write(i + ", ");
                    }
                }
                Console.WriteLine();
                Console.WriteLine("Чётные ==");
                foreach (int i in c)
                {
                    if (i != 0)
                    {
                        Console.Write(i + ", ");
                    }
                }
                Console.ReadKey();
            }
        }
    }

}
   