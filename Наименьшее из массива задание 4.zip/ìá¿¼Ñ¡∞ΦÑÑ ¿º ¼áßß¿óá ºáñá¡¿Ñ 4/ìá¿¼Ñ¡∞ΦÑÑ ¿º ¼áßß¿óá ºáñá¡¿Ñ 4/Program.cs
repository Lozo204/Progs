﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Наименьшее_из_массива_задание_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();

            int[] mas = new int[rnd.Next(1, 100 + 1)];
            for (int i = 0; i < mas.Length; i++)
            {
                mas[i] = rnd.Next(1, 100 + 1);
            }
            Sort(mas);
            Console.WriteLine("Введите числа в массиве");
            int nmas = Convert.ToInt32(Console.ReadLine());
            int nmas1 = mas.Length - nmas;

            for (int i = 0; i < nmas; i++)
            {
                Console.Write(mas[i] + " ");
            }


            Console.ReadKey();
        }
        static void Sort(int[] Array)
        {
            for (int i = 0; i < Array.Length; i++)
            {
                for (int j = 0; j < Array.Length - 1; j++)
                {
                    if (Array[j] > Array[j + 1])
                    {
                        int temp = Array[j];
                        Array[j] = Array[j + 1];
                        Array[j + 1] = temp;
                    }
                }
            }
        }
    }
}
