﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Преобразование_из_Цельсия_в_форентгейты
{
    class Program
    {
        static void Main(string[] args)
        {
            Double a;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.Title = ("Калькулятор");
            Console.WriteLine("Введите цельсии");
            a = Convert.ToDouble(Console.ReadLine());
            Console.Write("По форенгейту = ");
            Console.Write( a * 9 / 5 + 32);
            Console.ReadKey();

        }
    }
}
