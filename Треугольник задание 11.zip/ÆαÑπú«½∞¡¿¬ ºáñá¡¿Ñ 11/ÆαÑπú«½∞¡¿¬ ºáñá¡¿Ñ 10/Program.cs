﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Треугольник_задание_10
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c;
            
            Console.WriteLine("Введите a");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите b");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите c");
            c = Convert.ToInt32(Console.ReadLine());
            if (a + b <= c || a + c <= b || b + c <= a)
                Console.WriteLine("Такого треугольника не существует");
            else if (a == b && b == c)
                Console.WriteLine("Это равносторонний треугольник");
            else if (a == b || a == c || b == c)
                Console.WriteLine("Это равнобедренный треугольник");
            else 
                Console.WriteLine("Такой треугольник существует");
            Console.ReadKey();

        }
    }
}
