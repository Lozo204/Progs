﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Числа_превышающее_среднее_в_массиве_задание_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int[] a1 = new int[rnd.Next(1, 100 + 1)];
            int b1 = 0;
            double c1;

            for (int i = 0; i < a1.Length; i++)
            {
                a1[i] = rnd.Next(1, 100 + 1);
                b1 += a1[i];
            }

            foreach (int i in a1)
            {
                Console.Write(i + " ");
            }

            c1 = b1 / a1.Length;

            Console.WriteLine("\n" + c1 + "\n");
            Console.ReadKey();


            foreach (int i in a1)
            {
                if (i > c1)
                {
                    Console.Write(i + " ");
                }
            }
        }
    }
}
