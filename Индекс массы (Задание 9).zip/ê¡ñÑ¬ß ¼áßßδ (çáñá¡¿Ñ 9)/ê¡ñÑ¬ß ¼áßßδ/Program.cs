﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Индекс_массы
{
    class Program
    {
        static void Main(string[] args)
        {
            Double Rost, Ves;
            Console.WriteLine("Введите рост и вес");
            Rost = Convert.ToDouble(Console.ReadLine());
            Ves = Convert.ToDouble(Console.ReadLine());
            Console.Write("Индекс массы равен = "  + Ves / Rost*2);
            Console.ReadKey();
        }
    }
}
