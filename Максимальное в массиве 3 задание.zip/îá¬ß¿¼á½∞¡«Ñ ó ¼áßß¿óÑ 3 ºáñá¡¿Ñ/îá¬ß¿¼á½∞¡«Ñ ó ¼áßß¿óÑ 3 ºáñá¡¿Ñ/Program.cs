﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Максимальное_в_массиве_3_задание
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int[] n1 = new int[rnd.Next(1, 100 + 1)];
            for (int i = 0; i < n1.Length; i++)
            {
                n1[i] = rnd.Next(1, 100 + 1);
            }
            Sort(n1);
            Console.WriteLine("Введите к");
            int r = Convert.ToInt32(Console.ReadLine());
            int r1 = n1.Length - r;
            for (int i = n1.Length - 1; i > r1 - 1; i--)
            {
                Console.Write(n1[i] + " ");
            }


            Console.ReadKey();
        }
        static void Sort(int[] Array)
        {
            for (int i = 0; i < Array.Length; i++)
            {
                for (int j = 0; j < Array.Length - 1; j++)
                {
                    if (Array[j] > Array[j + 1])
                    {
                        int temp = Array[j];
                        Array[j] = Array[j + 1];
                        Array[j + 1] = temp;
                    }
                }
            }
        }
    }
}
