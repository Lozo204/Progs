﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_1_на_определение_значений
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = (101 + 0) / 3;
            Console.WriteLine(n1);
            double n2 = 3 * Math.Exp(-6) * 10000000.1;
            Console.WriteLine(n2);
            bool n3 = true && true;
            Console.WriteLine(n3);
            bool n4 = false && true;
            Console.WriteLine(n4);
            bool n5 = (false && false) && (false && true);
            Console.WriteLine(n5);
            bool n6 = (false && false) && (true && true);
            Console.WriteLine(n6);
            Console.ReadKey();
        }
    }
}
