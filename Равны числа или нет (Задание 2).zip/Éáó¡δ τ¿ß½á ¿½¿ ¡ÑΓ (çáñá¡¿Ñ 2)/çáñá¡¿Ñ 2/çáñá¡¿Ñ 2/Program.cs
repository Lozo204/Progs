﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Double a, b, c, d;
            Console.WriteLine("Введите числа");
            a = Convert.ToDouble(Console.ReadLine());
            b = Convert.ToDouble(Console.ReadLine());
            c = Convert.ToDouble(Console.ReadLine());
            d = Convert.ToDouble(Console.ReadLine());
            if (b == a && a == c && c == d)
            {
                Console.WriteLine("Числа равны");
            }
            else
            {
                Console.WriteLine("Не равны");
                
            }
            Console.ReadKey();
        }
    }
}
